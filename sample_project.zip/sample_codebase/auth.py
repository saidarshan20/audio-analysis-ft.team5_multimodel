import time

def signup(username, password):
    print(f"Creating user {username}...")
    return True

def login(username, password):
    print(f"Authenticating {username}...")
    # Mock JWT
    return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
