from auth import login, signup
from database import get_db

def main():
    print("Starting sample app...")
    db = get_db()
    signup("admin", "password123")
    token = login("admin", "password123")
    print(f"Logged in with token: {token}")

if __name__ == "__main__":
    main()
