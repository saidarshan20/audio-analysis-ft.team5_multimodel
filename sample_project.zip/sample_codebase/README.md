# Sample App
A small application to test code analysis.
