def get_db():
    print("Connecting to SQL database...")
    return "db_connection_object"
